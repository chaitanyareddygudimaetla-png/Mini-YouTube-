import { useState } from "react";
import { Play, Heart, Clock } from "lucide-react";

const sampleVideos = [
  {
    id: 1,
    title: "Sample Video 1",
    url: "https://www.w3schools.com/html/mov_bbb.mp4",
    thumbnail: "https://picsum.photos/id/1015/400/250",
    category: "Music",
  },
  {
    id: 2,
    title: "Sample Video 2",
    url: "https://www.w3schools.com/html/movie.mp4",
    thumbnail: "https://picsum.photos/id/1025/400/250",
    category: "Education",
  },
  {
    id: 3,
    title: "Sample Video 3",
    url: "https://www.w3schools.com/html/mov_bbb.mp4",
    thumbnail: "https://picsum.photos/id/1035/400/250",
    category: "Sports",
  },
];

export default function App() {
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [likes, setLikes] = useState([]);
  const [watchLater, setWatchLater] = useState([]);
  const [search, setSearch] = useState("");

  const toggleLike = (id) => {
    setLikes((prev) =>
      prev.includes(id) ? prev.filter((v) => v !== id) : [...prev, id]
    );
  };

  const toggleWatchLater = (id) => {
    setWatchLater((prev) =>
      prev.includes(id) ? prev.filter((v) => v !== id) : [...prev, id]
    );
  };

  const filteredVideos = sampleVideos.filter((v) =>
    v.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <h1 className="text-2xl font-bold mb-4 text-center">Mini YouTube 🎬</h1>

      {/* Search */}
      <div className="flex justify-center mb-6">
        <input
          type="text"
          placeholder="Search videos..."
          className="p-2 w-80 rounded border"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Video Player */}
      {selectedVideo && (
        <div className="mb-6">
          <video
            key={selectedVideo.id}
            src={selectedVideo.url}
            controls
            autoPlay
            className="w-full max-w-3xl mx-auto rounded-lg shadow"
          />
          <h2 className="mt-2 text-lg font-semibold">{selectedVideo.title}</h2>
        </div>
      )}

      {/* Video Feed */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredVideos.map((video) => (
          <div
            key={video.id}
            className="bg-white rounded-lg shadow hover:shadow-lg p-2"
          >
            <img
              src={video.thumbnail}
              alt={video.title}
              className="w-full rounded cursor-pointer"
              onClick={() => setSelectedVideo(video)}
            />
            <h3 className="font-semibold mt-2">{video.title}</h3>
            <p className="text-sm text-gray-500">{video.category}</p>

            <div className="flex justify-between mt-2">
              <button
                onClick={() => toggleLike(video.id)}
                className={`flex items-center gap-1 ${
                  likes.includes(video.id) ? "text-red-500" : "text-gray-600"
                }`}
              >
                <Heart size={18} /> Like
              </button>
              <button
                onClick={() => toggleWatchLater(video.id)}
                className={`flex items-center gap-1 ${
                  watchLater.includes(video.id)
                    ? "text-blue-500"
                    : "text-gray-600"
                }`}
              >
                <Clock size={18} /> Watch Later
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
